<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//Helper: application/helpers/pdf_helper.php
function tcpdf()
{
    require_once('tcpdf/config/lang/eng.php');
    require_once('tcpdf/tcpdf.php');
    //print_r($InsData);
}

function pdf_template($exp_policy_data,$site_url)
{
	/*$content = '';
	$content .= '<h1>HTML Example-</h1>'.$exp_policy_data['id'].'
<h2>List</h2>
List example:
<ol>
    <li><b>bold text</b></li>
    <li><i>italic text</i></li>
    <li><u>underlined text</u></li>
    <li><b>b<i>bi<u>biu</u>bi</i>b</b></li>
    <li><a href="http://www.tecnick.com" dir="ltr">link to http://www.tecnick.com</a></li>
    <li>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.<br />Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.</li>
    <li>SUBLIST
        <ol>
            <li>row one
                <ul>
                    <li>sublist</li>
                </ul>
            </li>
            <li>row two</li>
        </ol>
    </li>
    <li><b>T</b>E<i>S</i><u>T</u> <del>line through</del></li>
    <li><font size="+3">font + 3</font></li>
    <li><small>small text</small> normal <small>small text</small> normal <sub>subscript</sub> normal <sup>superscript</sup> normal</li>
</ol>
</div>';*/
$content = '';
/*$content .='<style>.header .logo h1 {
    display: inline-table;
    font-size: 20px;
    color: red;
    font-weight: 700;
	line-height:20px;
}</style>';*/
$content .= '<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><title>Acko</title><link href="'.$site_url.'assets/css/pdf_style.css" rel="stylesheet" type="text/css"></head><body>';

$content .= '<div id="container"><div id="wrapper"><div class="header"><div class="main-row">';
$content .= '<div class="logo"><a href="#"> <img src="'.$site_url.'assets/images/pdf-logo.jpg" alt=""><h1>LIABILITY ONLY POLICY - PRIVATE '.strtoupper($exp_policy_data['ins_type']).'</h1><p>Certificate of Insurance cum Policy Schedule</p></a></div></div></div>
<div class="section">
    <div class="main-row">
      <div class="policy-details">
        <div class="policy-left">
          <h3>POLICY DETAILS</h3>
          <ul>
            <li>Insured Name: <span>'.strtoupper($exp_policy_data['first_name']." ".$exp_policy_data['last_name']).'</span></li>
            <li>Address: <span>'.$exp_policy_data['primary_address_line1'].", ".$exp_policy_data['primary_address_line2'].", ".$exp_policy_data['primary_city'].", ".$exp_policy_data['primary_state'].'</span></li>
            <li>Pincode: <span>'.$exp_policy_data['primary_pin_code'].'</span></li>
            <li>GSTIN: <span>'.$exp_policy_data['company_gstin'].'</span></li>
            
            <li>Period of Insurance: <span>'.date("j F Y h:m", strtotime($exp_policy_data['payment_date'])).' hrs to '.date("j F Y h:m", strtotime('+364 day',$exp_policy_data['payment_date'])).' hrs</span></li>
            <!--<li>Period of Insurance: <span>01 March 20 00:00 hrs to 28 Feb 21 23:59 hrs</span></li>-->
            <li>Policy Issuance Date:<span>'.date("j F Y", strtotime($exp_policy_data['payment_date'])).'</span></li>
            <!--<li>Policy Number:<span>BBTA00262695292/00</span></li>-->
            <li>Nominee:<span>'.$exp_policy_data['nominee_name'].', '.$exp_policy_data['nominee_relation'].', '.$exp_policy_data['nominee_age'].'</span></li>
            <li>Owner Number:<span>'.$exp_policy_data['phone_no'].'</span></li>
            <!--<li>Previous Policy Expiry Date:<span>N/A</span></li>-->
          </ul>
        </div>
        <div class="policy-center">
          <h3>VEHICLE DETAILS</h3>
          <ul>
            <li>Registration Number:<span>'.$exp_policy_data['vehicle_registration_no'].'</span></li>
            <li>Make/Model:<span>'.$exp_policy_data['make_model'].'</span></li>
            <li>Registration Year: <span>'.$exp_policy_data['registration_year'].'</span></li>
            <li>Manufacturing Year:<span>'.date("j M, Y", strtotime($exp_policy_data['mfg_date'])).'</span></li>
            <li>Fuel Type: <span>'.$exp_policy_data['fuel_type'].'</span></li>
            <li>Engine No:<span>'.$exp_policy_data['engine_no'].'</span></li>
            <li>Chassis No:<span>'.$exp_policy_data['chassis_no'].'</span></li>
          </ul>
        </div>
        <div class="policy-right"><img src="'.$site_url.'assets/images/scan.jpg" alt=""></div>
      </div>
    </div>
  </div>';



$content .='</div></div>';

	return $content;
}
?>